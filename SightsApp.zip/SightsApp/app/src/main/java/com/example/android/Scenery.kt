package com.example.android

import android.widget.ImageView

data class Scenery(val image:Int,val name:String,val brief:String)