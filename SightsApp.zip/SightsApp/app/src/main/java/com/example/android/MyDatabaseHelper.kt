package com.example.notepad

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.android.sightseeing
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class MyDatabaseHelper(val context: Context, ):
    SQLiteOpenHelper(context, "NoteStore.db", null, 1) {
    //当数据库创建时执行的操作：创建数据库表SQL语句
    //保存创建数据库表的语句
    private val createNote="create table note("+
            "id integer primary key autoincrement,"+
            "content text"+
            ")"
    override fun onCreate(db: SQLiteDatabase?) {
        //表的创建
        db?.execSQL(createNote)
        //这个创建语句只会在数据库刚刚创建的时候执行一次，后续只会进行增删改查操作，不会再执行一次创建表的操作
    }
    //当数据库版本号更新时候执行的操作
    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        onCreate(db)
    }
    //增加插入收藏数据的操作
    fun insertData(content:String){
        //获取数据库
        val db=this.writableDatabase
        //组装数据
        val anote=ContentValues().apply {
           put("content",content)
        }
        db.insert("note", null,anote)
    }
    //读取所有的信息
    fun queryAll():ArrayList<sightseeing>{
        val list=ArrayList<sightseeing>()
        val db=this.writableDatabase
        val cursor=db.query("note",null,null,null,null,null,null,null)
       //通过游标对数据结果进行访问
        //如果后边还有值，就读取出来
        while(cursor.moveToNext()){
           val name=cursor.getString(1)
           list.add(sightseeing(name))
       }
        return list
    }
}