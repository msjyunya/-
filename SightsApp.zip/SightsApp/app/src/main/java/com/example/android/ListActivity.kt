package com.example.android

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.android.shanwei.R

class ListActivity : AppCompatActivity() {
     var cityName=""
    //景点图片、名称、简介的数据：
    //汕尾
   private val sceneryNames= arrayOf("红海湾","红宫红场","玄武山","保利","凤山祖庙","莲花山")
   private val briefs= arrayOf(" 红海湾遮浪岛是汕尾红海湾与碣石湾交接处向南伸出的一座形状很长的半岛，有“粤东麒麟角”之称。遮浪半岛于汕尾东南隅横生枝节，如屏障般横亘于碧波万顷的海面上。港湾避风条件良好，受海潮影响较小，一年四季万吨巨轮均可进出港口，有“百里海湾尽良港”之美称。",
       "红宫红场位于广东省海丰县城人民南路中段。是中国大革命时期，以彭湃同志为首的共产党人领导海陆丰人民建立的第一个苏维埃政权的革命活动场所。",
       "玄武山位于陆丰市碣石镇，元山寺建在玄武山南麓，占地15公顷，是佛道两教合一的宗教活动场所；也是粤东地区一处历史悠久、驰名海内外尤其是东南亚的名胜古迹，并且是闽南语系百姓的佛教信仰中心。寺内保存有大量寺藏历史文物，现已列为国家重点文物保护单位。",
       "保利金町湾位于 广东省汕尾市城区汕马路保利金町湾沙滩 是新开发展的旅游、游玩景区之一。汕尾金町湾是一个拥有7公里长的海边沙滩路程，每天景区游客高达数万人次的游览量，成为了远近闻名的旅游度假胜地。是集海滨休闲养生居住，商业旅游于一体的综合体海滨度假区。",
       "汕尾市凤山祖庙始建于明朝天启、崇祯年间（公元1621—1644年），庙内供奉的是清源妙道真君李二郎神，清乾隆年间（公元1736年—1796年）建宫殿式庙宇，称大使公。是广东省 粤东地区重要的传统民俗及民间宗教信仰之一。左传上有一句话：正直聪明之人为神。意思是说，只要为国家做过贡献，为人民谋利造福，必定会受到永恒的怀念和崇敬，而获得尚飨千秋俎豆的尊荣。",
       "莲花山坐落在汕尾市海丰县城北郊14公里的莲花山主峰南麓龙喷须。莲花山区南频南海，自然生态丰富多彩，有大珠三角的“后花园”之称。莲花山是广东四大山脉之一的莲花山脉主峰，海拔高度1337.6米，形成于燕山期造山运动。莲花山被十多座海拔千米的山峰环拥，层层叠翠，状如绽开之莲花。莲花山地处亚热带，累年平均气温为21.9度，日照偏少，气候宜人。"
    )
    private val imgIds= intArrayOf(
        R.drawable.hhw,
        R.drawable.hghc,
        R.drawable.xws,
        R.drawable.bl,
        R.drawable.fszm,
        R.drawable.lhs
    )

    //湛江
    private val zhanjiangNames= arrayOf("湖光岩","特呈岛","东海岛","波罗的海","角尾乡")
    private val zhanjiangbriefs= arrayOf(
        "湖光岩风景区位于中国大陆最南端湛江市区西南18公里处，被联合国地质专家称为研究地球与地质科学的“天然年鉴”。总面积为38平方公里，园区是一个以玛珥火山地质地貌为主体，兼有海岸地貌、构造地质地貌等多种地质遗迹，自然生态良好的公园。",
        "特呈岛，是广东湛江市湛江湾水道中间的一座小岛，“特呈”是古越语，“特”即地方，“呈”是和谐吉祥的意思。特呈岛离湛江市霞山区只有3海里，面积为3.6平方公里，为天然良港顶风抗浪保平安。",
        "东海岛是一个平坦而开阔的大海岛，面积286平方公里，享有中国第一长滩之美誉。",
        "徐闻县是闻名遐迩的“中国菠萝之乡”，广袤的菠萝种植形成的“菠萝的海”景区已成为当地知名的农业旅游景观。数十万亩菠萝连片成海，这般天然的田园旖旎风光，也被称为“北海道的花田”、“欧州的普罗旺斯”。",
        "角尾乡号称中国大陆最南端，位于湛江徐闻西南部，形如牛角。古有“极南”、“尽南”之称，拥有壮美的滨海景观、密集的人文史迹、浓郁的渔家风情、奇特的珊瑚建筑。中国大陆最南端端点灯楼角、琼州海峡与北部湾的合水线、中国大陆架最大最美的珊瑚礁群是中国独一无二的旅游资源。"
    )
    private val zhanjiangimgIds= intArrayOf(
        R.drawable.hgy,
        R.drawable.tcd,
        R.drawable.dhd,
        R.drawable.bldh,
        R.drawable.jwx,
    )

    private val beijingNames= arrayOf("故宫","八达岭","颐和园","天坛","潭柘寺")
    private val beijingbriefs= arrayOf(" 走进古老的宫墙里，怀念起故宫从前的名字——紫禁城，就能从空气中嗅到秋天的味道。一砖一瓦，一草一木都不知不觉的侵染了秋天的色彩，碧瓦飞甍，雕梁画栋，有一种穿越数百年的厚重与静美。",
        "八达岭长城，位于北京市延庆区军都山关沟古道北口。是中国古代伟大防御工程万里长城的重要组成部分，是明长城的一个隘口。八达岭长城为居庸关长城的重要前烧，古称“居庸之险不在关，而在八达岭”。",
        "颐和园风景秀丽，天高云淡。进东宫门，看到红色的院墙后有一棵还挂满着小金片的银杏树，欣喜它的叶子还没有掉！颐和园的水区域较大，大片的残荷在蓝色的湖面上，增强了冬色的渲染。阳光下随风摇曳的芦花，让人心生暖意。",
        "天坛是明、清两朝皇帝祭天、求雨和祈祷丰年的专用祭坛，分为内坛、外坛两部分，主要有祈年殿、皇乾殿等。 除了观赏各殿堂的精巧建筑，回音壁、三音石等奇巧的设计也一样令人慨叹古人的智慧。",
        "潭柘寺始建于1700多年前，历史非常悠久。曾经规模较大，传说明故宫便是仿造这里建造，北京有“先有潭柘寺，后有北京城”的谚语。寺院受重视，香火很旺。而且群山环抱、古树参天、建筑古老精美，风景非常不错。",
    )
    private val beijingimgIds= intArrayOf(
        R.drawable.gugong,
        R.drawable.badaling,
        R.drawable.yiheyuan,
        R.drawable.tiantan,
        R.drawable.tantuoshi
    )

    // 茂名
    private val mmsceneryNames= arrayOf("放鸡岛","浮山岭","浪漫海岸","中国第一滩","笔架山","新湖公园")
    private val mmbriefs= arrayOf(" 放鸡岛（原名湾舟岛，又名潜梦岛）是位于广东省茂名市电白区中心城区水东街道东南14.5公里的岛屿。横卧在茂名市电白区南海洋面，隶属于电白区博贺镇。岛上最高点高122米。面积1.9平方公里，是茂名市电白区最大的海岛。5月10日-12日，“海岛旅游发展与创新座谈会暨两广百强旅行社走进茂名考察活动”在放鸡岛举行，放鸡岛新品牌-——潜梦岛正式发布！",
        "浮山钟灵毓秀，是南粤百景之一，是茂名著名的生态旅游和农业观光旅游景区.浮山岭，是高州与电白分界山，北边高州市根子镇，南边电白区霞洞镇，有五个主峰，最高为最南边的主峰海拔高度为941米，在电白区霞洞镇境内，是茂名市郊相对高度最高、最陡的山。浮山岭山清水秀，树木郁葱，泉溪清澈，云雾缭绕，置于其间，恍若仙境。浮山岭还保留着纪念岭南道教的先驱潘茂名济世救民、得道成仙的修炼地超世寺，更有南国巾帼英雄冼英冼太夫人的冼太营地、冼太庙位于山腰之中。",
        "浪漫海岸国际旅游度假区，国家4A级旅游度假区，位于茂名市电白区博贺镇龙头山尖岗管理区海边，距茂名市中心城区40公里、电白区中心城区水东街道25公里,距放鸡岛12公里，以东南亚异域建筑风格和“浪漫”主题文化为特色，是广东省内拥有5.3公里私家海岸的滨海旅游度假区。",
        "中国第一滩旅游度假区（茂名滨海公园）位于广东省茂名市电白区南海街道海滨二路，是电白城区的重要组成部分。离茂名市中心城区25公里，距离电白中心城区水东街道10公里。有一级公路直达，交通便利。中国第一滩度假区有“东方夏威夷”之称。度假区内，形成了海滨浴场区、海上运动区、海滨度假区和中心广场区四个功能区，开发了海水浴、日光浴、海上运动、沙滩排球、烧烤、K歌、游乐设备、度假疗养等旅游项目。2017年5月31日茂名旅游岛·中国第一滩被广东省旅游协会批准为国家AAAA景区。",
        "笔架山，北魏时称安乐山，唐天宝年间称合江山，明代前期称少岷山，后期始称笔架山。南宋嘉熙四年（1240）为抵御元兵入侵，在此筑安乐山城作合江县治。笔架山是位于长江和赤水交汇处似笔架的一座丘陵型景观，为川南黔北的典型丹霞山和宗教名山。笔架山雄踞长江、赤水河交汇处的“三角洲”之上，海拔由220米上升到698米，相对高度较大，由于山峰耸立犹如笔架而得名。笔架山东西长2350米，南北宽252米，而山脊的最窄处仅2米。东西狭长、三峰耸立的地形，使人们从长江边眺望，笔架山石笋如巨笔直插云天，而从赤水河边仰视，笔架山三座山峰又似笔架横亘大地。",
        "新湖公园位于茂名市区人民北路，是茂名市城区最大的公园，于1987年建成对游人开放。公园面积为22.26公顷，其中水面积10.13公顷；建筑面积只有0.28公顷，仅占总面积的1.3%。公园有儿童乐园，水上乐园、游艇码头、咖啡厅、展厅等主要设施。2019年新湖公园改造升级，旨在打造一个多元化生态休闲公园，工程涉及多方面内容。如新建两道跨湖桥、4个亲水平台，并增建卫生间，让市民到新湖公园游玩更加便利。新建多个主题小广场，涉及党建、书法、音乐等，增加书香气息和文化元素，并增加老人健身场所、儿童乐园等。"
    )
    private val mmimgIds= intArrayOf(
        R.drawable.fangjidao,
        R.drawable.fushan,
        R.drawable.langman,
        R.drawable.diyitan,
        R.drawable.bijisan,
        R.drawable.xinhu
    )


    //得到景点列表对象（构造方法）
    val sceneryList=ArrayList<Scenery>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        val title=findViewById<TextView>(R.id.title)
        //此处获取点击的城市名
        cityName = intent.getStringExtra("cityName").toString()
        title.setText("欢迎来到"+cityName)
        //数据初始化，得到景点列表
        init()

        val adapter= MyAdapter(sceneryList)
        var linearLayoutManager = LinearLayoutManager(this)
        var recyclerview=findViewById<RecyclerView>(R.id.recyclerView)
        recyclerview.adapter=adapter
        recyclerview.layoutManager=linearLayoutManager

        val image=findViewById<ImageView>(R.id.imageView)
        image.setOnClickListener{
            val intent= Intent(this,AddActivity::class.java)
            startActivity(intent)
        }
        }


        //初始化不同的地点数据
        fun init(){
            repeat(2) {
                when (cityName) {
                    "汕尾" -> for (i in 0..5) {
                        sceneryList.add(Scenery(imgIds[i], sceneryNames[i], briefs[i]))
                    }
                    "湛江" -> for (i in 0..4) {
                        sceneryList.add(Scenery(zhanjiangimgIds[i], zhanjiangNames[i], zhanjiangbriefs[i]))
                    }
                    "北京" -> for (i in 0..4) {
                        sceneryList.add(Scenery(beijingimgIds[i], beijingNames[i], beijingbriefs[i]))
                    }
                    "茂名" -> for (i in 0..5){
                        sceneryList.add(Scenery(mmimgIds[i], mmsceneryNames[i], mmbriefs[i]))
                    }

                }

            }
        }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        getMenuInflater().inflate(R.menu.activity_menu,menu);
        return true;
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return when (item.itemId) {
            R.id.bottom_menu_home -> {
                Toast.makeText(this,"回到主页", Toast.LENGTH_SHORT).show()
                var intent= Intent(this,MainActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.bottom_menu_found -> {
               /* Toast.makeText(this,"停留在此页", Toast.LENGTH_SHORT).show()*/
                Toast.makeText(this,"回到主页", Toast.LENGTH_SHORT).show()
                var intent= Intent(this,CitySelectActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.bottom_menu_message -> {
                Toast.makeText(this,"进入收藏夹", Toast.LENGTH_SHORT).show()
                var intent = Intent(this,CollectActivity::class.java)
                startActivity(intent)
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
}