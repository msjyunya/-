package com.example.android

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.android.shanwei.R
import com.google.android.material.bottomnavigation.BottomNavigationView
//, BottomNavigationView.OnNavigationItemSelectedListener
class CitySelectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_city_select)
        val image_1:ImageView = findViewById(R.id.shanwei)
        val image_2:ImageView =findViewById(R.id.zhanjiang)
        val image_3:ImageView =findViewById(R.id.beijing)
        val image_4:ImageView = findViewById(R.id.maoming)
        val addimage:ImageView=findViewById(R.id.imageView)
        image_1.setOnClickListener{
            val cityName = "汕尾"
            Toast.makeText(this, "欢迎来到汕尾！", Toast.LENGTH_SHORT).show()
            val intent= Intent(this, ListActivity::class.java)
            intent.putExtra("cityName",cityName)
            startActivity(intent)
        }
        image_2.setOnClickListener{
            val cityName = "湛江"
            Toast.makeText(this, "欢迎来到湛江！", Toast.LENGTH_SHORT).show()
            val intent= Intent(this, ListActivity::class.java)
            intent.putExtra("cityName",cityName)
            startActivity(intent)
        }
        image_3.setOnClickListener{
            val cityName = "北京"
            Toast.makeText(this, "欢迎来到北京！", Toast.LENGTH_SHORT).show()
            val intent= Intent(this, ListActivity::class.java)
            intent.putExtra("cityName",cityName)
            startActivity(intent)
        }
        image_4.setOnClickListener{
            val cityName = "茂名"
            Toast.makeText(this, "欢迎来到茂名！", Toast.LENGTH_SHORT).show()
            val intent= Intent(this, ListActivity::class.java)
            intent.putExtra("cityName",cityName)
            startActivity(intent)
        }
        addimage.setOnClickListener{
            val intent= Intent(this, AddActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (menu != null) {
            menu.add(1,1,0,"回到首页")
            menu.add(2,2,0,"收藏夹")
        }
        return true;
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return when (item.itemId) {
            1 -> {
                Toast.makeText(this,"回到主页",Toast.LENGTH_SHORT).show()
                val intent=Intent(this,MainActivity::class.java)
                startActivity(intent)
                true
            }
            2 -> {
                Toast.makeText(this,"进入收藏夹", Toast.LENGTH_SHORT).show()
                val intent = Intent(this,CollectActivity::class.java)
                startActivity(intent)
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
        //点击添加图片切到添加景点收藏内容
        val image=findViewById<ImageView>(R.id.imageView)
        image.setOnClickListener{
            val intent= Intent(this,AddActivity::class.java)
            startActivity(intent)
        }
    }
//    override fun onNavigationItemSelected(item: MenuItem): Boolean {
//        when (item.itemId) {
//            R.id.bottom_menu_home -> {
//                Toast.makeText(this,"回到主页",Toast.LENGTH_SHORT).show()
//                var intent=Intent(this,MainActivity::class.java)
//                startActivity(intent)
//            }
//            R.id.bottom_menu_found -> {
//                Toast.makeText(this,"城市列表",Toast.LENGTH_SHORT).show()
//                var intent=Intent(this,ListActivity::class.java)
//                startActivity(intent)
//            }
//            R.id.bottom_menu_message -> {
//
//            }
//        }
//        return true
//    }
}