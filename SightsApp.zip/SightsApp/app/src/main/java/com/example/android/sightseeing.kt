package com.example.android

//数据封装，封装了风景的名字
data class sightseeing (val name:String)