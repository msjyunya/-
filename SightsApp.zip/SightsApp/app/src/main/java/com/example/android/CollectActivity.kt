package com.example.android

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.android.shanwei.R
import com.example.notepad.MyDatabaseHelper

class CollectActivity : AppCompatActivity() {
    var sights=ArrayList<sightseeing>()
override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_collect)
    //数据初始化
    //读取数据库，初始化列表
    val dbHelper = MyDatabaseHelper(this)
    sights = dbHelper.queryAll()
    //子项：子项封装类、子项布局、Adapter
    //添加列表
    val adapter = sightsAdapter(sights)
    val linearLayoutManager = LinearLayoutManager(this)
    val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
    recyclerView.adapter = adapter
    recyclerView.layoutManager = linearLayoutManager
}
}