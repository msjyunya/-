package com.example.android

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.android.shanwei.R
import com.example.notepad.MyDatabaseHelper

class AddActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        val save=findViewById<ImageView>(R.id.imageView)
        val noteContent=findViewById<EditText>(R.id.noteContent)
        //创建数据库操作对象
        val dbHelper= MyDatabaseHelper(this)
        //获取add按钮，点击按钮可以访问数据库，添加收藏景点
        save.setOnClickListener{
            //获取界面填写的内容，存储到数据库
            val noteContent=noteContent.text.toString()
            if(!TextUtils.isEmpty(noteContent.trim())) {
                dbHelper.insertData(noteContent)
                //销毁添加界面
                finish()
            }else{
                Toast.makeText(this,"内容不能为空",Toast.LENGTH_SHORT).show()
            }
        }
    }
}