package com.example.android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.android.shanwei.R

class ItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item)
        val imageView=findViewById<ImageView>(R.id.image)
        val title=findViewById<TextView>(R.id.title)
        val content=findViewById<TextView>(R.id.content)
        val image=intent.getIntExtra("image", R.drawable.hhw)
        val name=intent.getStringExtra("name")
        val brief=intent.getStringExtra("brief")
        imageView.setImageResource(image)
        title.setText(name)
        content.setText(brief)
    }
}