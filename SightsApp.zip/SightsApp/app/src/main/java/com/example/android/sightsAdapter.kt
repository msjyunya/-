package com.example.android

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.android.shanwei.R

class sightsAdapter(var list:ArrayList<sightseeing>) :RecyclerView.Adapter<sightsAdapter.ViewHolder>(){
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val sightsContent = itemView.findViewById<TextView>(R.id.item_content)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.sights_item_layout,parent,false)
        val viewHolder = ViewHolder(view)
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val s = list.get(position)
        holder.sightsContent.setText(s.name)
    }

    override fun getItemCount(): Int = list.size
}